package cn.edu.bzu.ie.mysqldb;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ShangPin extends AppCompatActivity {
    private TextView tv_main_title;//标题
    private TextView tv_back;
    private RelativeLayout rl_title_bar;
    private Button Button4;
    private ImageView ImageView1, ImageView2 ,ImageView3, ImageView4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shangpin);
        tv_back=findViewById(R.id.tv_back);
        Button4=findViewById(R.id.button4);
        ImageView1=findViewById(R.id.imageView1);
        ImageView2=findViewById(R.id.imageView2);
        ImageView3=findViewById(R.id.imageView3);
        ImageView4=findViewById(R.id.imageView4);

        tv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //创建Intent 对象
                Intent intent=new Intent(ShangPin.this,FenLei.class);
                //启动Activity
                startActivity(intent);
            }
        });
        Button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //创建Intent 对象
                Intent intent=new Intent(ShangPin.this,ShiPin.class);
                //启动Activity
                startActivity(intent);
            }
        });
        ImageView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //创建Intent 对象
                Intent intent=new Intent(ShangPin.this,ShiPin2.class);
                //启动Activity
                startActivity(intent);
            }
        });
        ImageView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //创建Intent 对象
                Intent intent=new Intent(ShangPin.this,ShiPin3.class);
                //启动Activity
                startActivity(intent);
            }
        });
        ImageView3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //创建Intent 对象
                Intent intent=new Intent(ShangPin.this,ShiPin4.class);
                //启动Activity
                startActivity(intent);
            }
        });
        ImageView4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //创建Intent 对象
                Intent intent=new Intent(ShangPin.this,ShiPin5.class);
                //启动Activity
                startActivity(intent);
            }
        });
    }
}
