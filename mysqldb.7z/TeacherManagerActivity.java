package cn.edu.bzu.ie.mysqldb;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.ListView;

import java.util.List;

/**
 * 用户管理界面业务逻辑
 */
public class TeacherManagerActivity extends AppCompatActivity implements View.OnClickListener {
    private ImageView btn_return;   // 返回图片按钮

    private TeacherDao teacherDao;    // 用户数据库操作实例

    private List<Teacherinfo> teacherinfoList;   // 用户数据集合
    private LvTeacherinfoAdapter lvTeacherinfoAdapter;   // 用户信息数据适配器

    private ListView lv_teacher;   // 用户列表组件

    private Handler mainHandler;   // 主线程

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher_manage);

        initView();
        loadTeacherDb();
    }

    private void initView(){
        btn_return = findViewById(R.id.btn_return);
        lv_teacher = findViewById(R.id.lv_teacher);

        teacherDao = new TeacherDao();
        mainHandler = new Handler(getMainLooper());

        btn_return.setOnClickListener(this);
    }

    private void loadTeacherDb(){
        new Thread(new Runnable() {
            @Override
            public void run() {
                teacherinfoList = teacherDao.getAllTeacherList();   // 获取所有的用户数据
                mainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        showLvData();
                    }
                });
            }
        }).start();
    }

    // 显示列表数据的方法
    private void showLvData(){
        if(lvTeacherinfoAdapter==null){   // 首次加载时的操作
            lvTeacherinfoAdapter = new LvTeacherinfoAdapter(this, teacherinfoList);
            lv_teacher.setAdapter(lvTeacherinfoAdapter);
        }else{   // 更新数据时的操作
            lvTeacherinfoAdapter.setTeacherinfoList(teacherinfoList);
            lvTeacherinfoAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btn_return:
                finish();
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==1 && resultCode==1){   // 操作成功
            loadTeacherDb();   // 重新加载数据
        }
    }
}
