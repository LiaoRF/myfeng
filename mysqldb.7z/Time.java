package cn.edu.bzu.ie.mysqldb;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.view.View;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Timer;
import java.util.TimerTask;

public class Time extends AppCompatActivity implements View.OnClickListener, Chronometer.OnChronometerTickListener{
    private TextView tv_back;
    private Chronometer chronometer;
    private Button btn_start,btn_stop,btn_base,btn_format;
    private EditText inputet;
    private Button get, startTime, stopTime;
    private TextView time;
    private int i = 0;
    private Timer timer = null;
    private TimerTask task = null;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_time);
        tv_back=findViewById(R.id.tv_back);
        initView();
        initViewCount();

        tv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //创建Intent 对象
                Intent intent=new Intent(Time.this,FenLei.class);
                //启动Activity
                startActivity(intent);
            }
        });
    }

    private void initView() {
        chronometer = (Chronometer) findViewById(R.id.chronometer);
        btn_start = (Button) findViewById(R.id.btnStart);
        btn_stop = (Button) findViewById(R.id.btnStop);
        btn_base = (Button) findViewById(R.id.btnReset);
        btn_format = (Button) findViewById(R.id.btn_format);

        chronometer.setOnChronometerTickListener(this);
        btn_start.setOnClickListener(this);
        btn_stop.setOnClickListener(this);
        btn_base.setOnClickListener(this);
        btn_format.setOnClickListener(this);
    }

    private void initViewCount() {
        inputet = findViewById(R.id.timecount_input);
        get = findViewById(R.id.btn_timecount_get);
        startTime = findViewById(R.id.btn_timecount_starttime);
        stopTime = findViewById(R.id.btn_timecount_stoptime);
        time = findViewById(R.id.time);
        get.setOnClickListener(this);
        startTime.setOnClickListener(this);
        stopTime.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnStart:
                chronometer.start();// 开始计时
                break;
            case R.id.btnStop:
                chronometer.stop();// 停止计时
                break;
            case R.id.btnReset:
                chronometer.setBase(SystemClock.elapsedRealtime());// 复位
                break;
            case R.id.btn_format:
                chronometer.setFormat("Time：%s");// 更改时间显示格式
                break;
            case R.id.btn_timecount_get:
                time.setText(inputet.getText().toString());
                i = Integer.parseInt(inputet.getText().toString());
                break;
            case R.id.btn_timecount_starttime:
                startTime();
                break;
            case R.id.btn_timecount_stoptime:
                stopTime();
                break;
            default:
                break;
        }

    }

    //Time
    @Override
    public void onChronometerTick(Chronometer chronometer) {
        String time = chronometer.getText().toString();
        if(time.equals("00:00")){
            Toast.makeText(Time.this,"真棒！时间到了!再来一次吧！", Toast.LENGTH_SHORT).show();
        }
    }

    //TimeCount
    private Handler mHandler = new Handler() {
        public void handleMessage(Message msg) {
            time.setText("还有"+msg.arg1 + "s,坚持！");
            startTime();
        };
    };

    public void startTime() {
        timer = new Timer();
        task = new TimerTask() {

            @Override
            public void run() {
                if (i > 0) {   //加入判断不能小于0
                    i--;
                    Message message = mHandler.obtainMessage();
                    message.arg1 = i;
                    mHandler.sendMessage(message);
                }
            }
        };
        timer.schedule(task, 1000); //一秒进行一次
    }

    public void stopTime(){
        timer.cancel();
    }

}