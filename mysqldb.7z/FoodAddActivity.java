package cn.edu.bzu.ie.mysqldb;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

/**
 * 添加用户的业务代码
 */
public class FoodAddActivity extends AppCompatActivity {
    private EditText et_foodname, et_foodif;
    private TextView tv_back;//返回键

    private FoodDao foodDao;   // 用户数据操作类实例

    private Handler mainHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food_add);

        et_foodname = findViewById(R.id.et_foodname);
        et_foodif = findViewById(R.id.et_foodif);
        tv_back = findViewById(R.id.tv_back);

        foodDao = new FoodDao();
        mainHandler = new Handler(getMainLooper());
        init();
    }

    private void init(){
        tv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //创建Intent 对象
                Intent intent=new Intent(FoodAddActivity.this,FoodManagerActivity.class);
                //启动Activity
                startActivity(intent);
            }
        });
    }

    // 确定按钮的点击事件处理
    public void btn_ok_click(View view){
        final String foodname = et_foodname.getText().toString().trim();
        final String foodif = et_foodif.getText().toString().trim();

        if(TextUtils.isEmpty(foodname)){
            CommonUtils.showShortMsg(this, "请输入食物名称");
            et_foodname.requestFocus();
        }else if(TextUtils.isEmpty(foodif)){
            CommonUtils.showShortMsg(this, "请输入食物信息");
            et_foodif.requestFocus();
        }else{
            final Foodinfo item = new Foodinfo();

            item.setFoodname(foodname);
            item.setFoodif(foodif);
            item.setCreateDt(CommonUtils.getDateStrFromNow());

            new Thread(new Runnable() {
                @Override
                public void run() {
                    final int iRow = foodDao.addFood(item);

                    mainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            setResult(1);   // 使用参数表示当前界面操作成功，并返回管理界面
                            finish();
                        }
                    });
                }
            }).start();
        }

    }
}
