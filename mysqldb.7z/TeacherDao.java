package cn.edu.bzu.ie.mysqldb;

import java.util.ArrayList;
import java.util.List;

/**
 * 教练数据库操作类
 */
public class TeacherDao extends DbOpenHelper {

    //     查询所有的用户信息 R
    public List<Teacherinfo> getAllTeacherList(){
        List<Teacherinfo> list = new ArrayList<>();
        try{
            getConnection();   // 取得连接信息
            String sql = "select * from teacherinfo";
            pStmt = conn.prepareStatement(sql);
            rs = pStmt.executeQuery();
            while(rs.next()){   // 这里原来用的是if，查询数据集合时应使用while
                Teacherinfo item = new Teacherinfo();
                item.setId(rs.getInt("teacherid"));
                item.setTeachername(rs.getString("tname"));
                item.setTeacherpass(rs.getString("info"));

                list.add(item);
            }
        }catch(Exception ex){
            ex.printStackTrace();
        }finally {
            closeAll();
        }
        return list;
    }

}
