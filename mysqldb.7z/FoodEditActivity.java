package cn.edu.bzu.ie.mysqldb;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

/**
 * 修改用户 界面业务逻辑
 */
public class FoodEditActivity extends AppCompatActivity {
    private EditText et_foodname, et_foodif;

    private TextView tv_createDt;

    private FoodDao foodDao;   // 用户数据操作类实例

    private Foodinfo foodEdit;   // 当前要修改的用户信息

    private Handler mainHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food_edit);

        et_foodname = findViewById(R.id.et_foodname);
        et_foodif = findViewById(R.id.et_foodif);
        tv_createDt = findViewById(R.id.tv_createDt);

        Bundle bundle = getIntent().getExtras();
        if(bundle!=null){
            foodEdit = (Foodinfo)bundle.getSerializable("foodEdit");

            et_foodname.setText(foodEdit.getFoodname());
            et_foodif.setText(foodEdit.getFoodif());
            tv_createDt.setText(foodEdit.getCreateDt());
        }

        foodDao = new FoodDao();
        mainHandler = new Handler(getMainLooper());
    }

    // 确定按钮的点击事件处理
    public void btn_ok_click(View view){
        final String foodname = et_foodname.getText().toString().trim();
        final String foodif = et_foodif.getText().toString().trim();

        if(TextUtils.isEmpty(foodname)){
            CommonUtils.showShortMsg(this, "请输入食物名称");
            et_foodname.requestFocus();
        }else if(TextUtils.isEmpty(foodif)){
            CommonUtils.showShortMsg(this, "请输入食物信息");
            et_foodif.requestFocus();
        }else{
            foodEdit.setFoodname(foodname);
            foodEdit.setFoodif(foodif);

            new Thread(new Runnable() {
                @Override
                public void run() {
                    final int iRow = foodDao.editFood(foodEdit);

                    mainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            setResult(1);   // 使用参数表示当前界面操作成功，并返回管理界面
                            finish();
                        }
                    });
                }
            }).start();
        }
    }
}
