package cn.edu.bzu.ie.mysqldb;


import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.net.Uri;
import android.widget.MediaController;
import android.widget.VideoView;

import androidx.appcompat.app.AppCompatActivity;

public class FenLei extends AppCompatActivity {
    private TextView tv_back;
    private Button button2, button3, btn_fl_shipu,btn_fl_time;
    private Button btn_fl_jiaolian;
    private Button btn_fl_run;
    private Button btn_fl_person,btn_fl_bmi, getBtn_fl_jiaolian;


        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_fenlei);
            tv_back=findViewById(R.id.tv_back);
            button2=findViewById(R.id.button2);
            button3=findViewById(R.id.button3);
            btn_fl_shipu = findViewById(R.id.btn_fl_shipu);
            btn_fl_time = findViewById(R.id.btn_fl_time);
            btn_fl_jiaolian = findViewById(R.id.btn_fl_jiaolian);
            btn_fl_run = findViewById(R.id.btn_fl_run);
            btn_fl_person = findViewById(R.id.btn_fl_person);
            btn_fl_bmi = findViewById(R.id.btn_fl_bmi);
            getBtn_fl_jiaolian = findViewById(R.id.btn_fl_jiaolian);


            tv_back.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    //创建Intent 对象
                    Intent intent=new Intent(FenLei.this,SplashActivity.class);
                    //启动Activity
                    startActivity(intent);
                }
            });
            button2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    //创建Intent 对象
                    Intent intent=new Intent(FenLei.this,ShangPin.class);
                    //启动Activity
                    startActivity(intent);
                }
            });
            button3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent=new Intent(Intent.ACTION_MAIN);
                    intent.addCategory(Intent.CATEGORY_LAUNCHER);
//参数是包名，类全限定名，注意直接用类名不行
                    ComponentName cn=new ComponentName("com.example.myassignment_gzh",
                            "com.example.myassignment_gzh.DrawerLayoutUsing");
                    intent.setComponent(cn);
                    startActivity(intent);

                }
            });

            btn_fl_shipu.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    //创建Intent 对象
                    Intent intent=new Intent(FenLei.this,FoodManagerActivity.class);
//                    Log.i("shipu","跳转到食谱页面");
                    //启动Activity
                    startActivity(intent);
                }
            });
            btn_fl_time.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    //创建Intent 对象
//                    Intent intent=new Intent(FenLei.this,Time.class);
                    Intent intent2=new Intent(FenLei.this,Time.class);
                    //启动Activity
//                    startActivity(intent);
                    startActivity(intent2);
                }
            });
            btn_fl_run.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    //创建Intent 对象
//                    Intent intent=new Intent(FenLei.this,Time.class);
//                    Intent intent2=new Intent(FenLei.this,Time.class);
                    //启动Activity
//                    startActivity(intent);
//                    startActivity(intent2);
                    Intent intent=new Intent(Intent.ACTION_MAIN);
                    intent.addCategory(Intent.CATEGORY_LAUNCHER);
//参数是包名，类全限定名，注意直接用类名不行
                    ComponentName cn=new ComponentName("com.james.motion",
                            "com.james.motion.ui.activity.SplashActivity");
                    intent.setComponent(cn);
                    startActivity(intent);

                }
            });
            btn_fl_person.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent=new Intent(FenLei.this,UserManagerActivity.class);
                    startActivity(intent);
                }
            });
            btn_fl_bmi.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent=new Intent(FenLei.this,BmiCount.class);
                    startActivity(intent);
                }
            });
            getBtn_fl_jiaolian.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent=new Intent(FenLei.this, TeacherManagerActivity.class);
                    startActivity(intent);
                }
            });



        }

}

