package cn.edu.bzu.ie.mysqldb;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class FubuPlan extends AppCompatActivity {
    private TextView tv_main_title;//标题
    private TextView tv_back;
    private RelativeLayout rl_title_bar;
    private ImageView imageView1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shangpin);
        tv_back=findViewById(R.id.tv_back);
        imageView1=findViewById(R.id.imageView1);
        tv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //创建Intent 对象
                Intent intent=new Intent(FubuPlan.this,FenLei.class);
                //启动Activity
                startActivity(intent);
            }
        });
        imageView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //创建Intent 对象
                Intent intent=new Intent(FubuPlan.this,ShiPin.class);
                //启动Activity
                startActivity(intent);
            }
        });
    }
}
