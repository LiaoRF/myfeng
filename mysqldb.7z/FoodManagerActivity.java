package cn.edu.bzu.ie.mysqldb;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.ListView;

import java.util.List;

/**
 * 用户管理界面业务逻辑
 */
public class FoodManagerActivity extends AppCompatActivity implements View.OnClickListener {
    private ImageView btn_return, btn_add;   // 返回图片按钮 ，添加图片按钮

    private FoodDao foodDao;    // 用户数据库操作实例

    private List<Foodinfo> foodinfoList;   // 用户数据集合
    private LvFoodinfoAdapter lvFoodinfoAdapter;   // 用户信息数据适配器

    private ListView lv_food;   // 用户列表组件

    private Handler mainHandler;   // 主线程

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food_manager);

        initView();
        loadFoodDb();
    }

    private void initView(){
        btn_return = findViewById(R.id.btn_return);
        btn_add = findViewById(R.id.btn_add);

        lv_food = findViewById(R.id.lv_food);

        foodDao = new FoodDao();
        mainHandler = new Handler(getMainLooper());

        btn_return.setOnClickListener(this);
        btn_add.setOnClickListener(this);
    }

    private void loadFoodDb(){
        new Thread(new Runnable() {
            @Override
            public void run() {
                foodinfoList = foodDao.getAllFoodList();   // 获取所有的用户数据
                mainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        showLvData();
                    }
                });
            }
        }).start();
    }

    // 显示列表数据的方法
    private void showLvData(){
        if(lvFoodinfoAdapter==null){   // 首次加载时的操作
            lvFoodinfoAdapter = new LvFoodinfoAdapter(this, foodinfoList);
            lv_food.setAdapter(lvFoodinfoAdapter);
        }else{   // 更新数据时的操作
            lvFoodinfoAdapter.setFoodinfoList(foodinfoList);
            lvFoodinfoAdapter.notifyDataSetChanged();
        }

        // 修改按钮的操作
        lvFoodinfoAdapter.setOnEditBtnClickListener(new OnEditBtnClickListener() {
            @Override
            public void onEditBtnClick(View view, int position) {
                // 修改按钮的操作
                Foodinfo item = foodinfoList.get(position);
                Bundle bundle = new Bundle();
                bundle.putSerializable("foodEdit", item);
                Intent intent = new Intent(FoodManagerActivity.this, FoodEditActivity.class);
                intent.putExtras(bundle);
                startActivityForResult(intent, 1);
            }
        });

        // 删除按钮的操作
        lvFoodinfoAdapter.setOnDelBtnClickListener(new OnDelBtnClickListener() {
            @Override
            public void onDelBtnClick(View view, int position) {
                //  删除方法
                final Foodinfo item = foodinfoList.get(position);
                new AlertDialog.Builder(FoodManagerActivity.this)
                        .setTitle("删除确定")
                        .setMessage("您确定要删除：id:["+item.getId()+"]，foodname:["+
                                item.getFoodname()+"]的用户信息吗？")
                        .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                doDelFood(item.getId());
                            }
                        })
                        .setNegativeButton("取消", null)
                        .create().show();
            }
        });
    }

    /**
     * 执行删除用户的方法
     * @param id 要删除用户的id
     */
    private void doDelFood(final int id){
        new Thread(new Runnable() {
            @Override
            public void run() {
                final int iRow = foodDao.delFood(id);
                mainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        loadFoodDb();  // 重新加载数据
                    }
                });
            }
        }).start();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btn_return:
                finish();
                break;
            case R.id.btn_add:
                // 代码桩，打开添加用户界面
                Intent intent = new Intent(this, FoodAddActivity.class);
                startActivityForResult(intent, 1);
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==1 && resultCode==1){   // 操作成功
            loadFoodDb();   // 重新加载数据
        }
    }
}
