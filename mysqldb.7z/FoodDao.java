package cn.edu.bzu.ie.mysqldb;

import java.util.ArrayList;
import java.util.List;

/**
 * 用户数据库操作类
 * 实现食物的CRUD操作
 */
public class FoodDao extends DbOpenHelper {

    // 查询所有的用户信息 R
    public List<Foodinfo> getAllFoodList(){
        List<Foodinfo> list = new ArrayList<>();
        try{
            getConnection();   // 取得连接信息
            String sql = "select * from foodinfo";
            pStmt = conn.prepareStatement(sql);
            rs = pStmt.executeQuery();
            while(rs.next()){   // 这里原来用的是if，查询数据集合时应使用while
                Foodinfo item = new Foodinfo();
                item.setId(rs.getInt("id"));
                item.setFoodname(rs.getString("foodname"));
                item.setFoodif(rs.getString("foodif"));
                item.setCreateDt(rs.getString("createDt"));

                list.add(item);
            }
        }catch(Exception ex){
            ex.printStackTrace();
        }finally {
            closeAll();
        }
        return list;
    }

    /**
     * 按用户名和密码查询用户信息 R
     * @param foodname 食物名
     * @param foodif 密码
     * @return Foodinfo 实例
     */
    public Foodinfo getFoodByFoodnameAndFoodif(String foodname, String foodif){
        Foodinfo item = null;
        try{
            getConnection();   // 取得连接信息
            String sql = "select * from foodinfo where foodname=? and foodif=?";
            pStmt = conn.prepareStatement(sql);
            pStmt.setString(1, foodname);
            pStmt.setString(2, foodif);
            rs = pStmt.executeQuery();
            if(rs.next()){
                item = new Foodinfo();
                item.setId(rs.getInt("id"));
                item.setFoodname(foodname);
                item.setFoodif(foodif);
                item.setCreateDt(rs.getString("createDt"));
            }
        }catch(Exception ex){
            ex.printStackTrace();
        }finally {
            closeAll();
        }
        return item;
    }

    /**
     * 添加用户信息 C
     * @param item 要添加的用户
     * @return int 影响的行数
     */
    public int addFood(Foodinfo item){
        int iRow = 0;
        try{
            getConnection();   // 取得连接信息
            String sql = "insert into foodinfo(foodname, foodif, createDt) values(?, ?, ?)";
            pStmt = conn.prepareStatement(sql);
            pStmt.setString(1, item.getFoodname());
            pStmt.setString(2, item.getFoodif());
            pStmt.setString(3, item.getCreateDt());
            iRow = pStmt.executeUpdate();
        }catch(Exception ex){
            ex.printStackTrace();
        }finally {
            closeAll();
        }
        return iRow;
    }

    /**
     * 修改用户信息 U
     * @param item 要修改的用户
     * @return int 影响的行数
     */
    public int editFood(Foodinfo item){
        int iRow = 0;
        try{
            getConnection();   // 取得连接信息
            String sql = "update foodinfo set foodname=?, foodif=? where id=?";
            pStmt = conn.prepareStatement(sql);
            pStmt.setString(1, item.getFoodname());
            pStmt.setString(2, item.getFoodif());
            pStmt.setInt(3, item.getId());
            iRow = pStmt.executeUpdate();
        }catch(Exception ex){
            ex.printStackTrace();
        }finally {
            closeAll();
        }
        return iRow;
    }

    /**
     * 根据id 删除用户信息
     * @param id 要删除用户的id
     * @return int 影响的行数
     */
    public int delFood(int id){
        int iRow = 0;
        try{
            getConnection();   // 取得连接信息
            String sql = "delete from foodinfo where id=?";
            pStmt = conn.prepareStatement(sql);
            pStmt.setInt(1, id);
            iRow = pStmt.executeUpdate();
        }catch(Exception ex){
            ex.printStackTrace();
        }finally {
            closeAll();
        }
        return iRow;
    }
}
