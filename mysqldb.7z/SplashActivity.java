//package cn.edu.bzu.ie.mysqldb;
//
//import android.content.Intent;
//import android.os.Bundle;
//import android.os.Handler;
//import android.text.TextUtils;
//import android.view.View;
//import android.widget.Button;
//import android.widget.EditText;
//
//import androidx.appcompat.app.AppCompatActivity;
//
//public class SplashActivity extends AppCompatActivity {
//    private Handler mHandler = new Handler();
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_splash);
//        mHandler.postDelayed(new Runnable() {
//            @Override
//            public void run() {
//                startActivity(new Intent(SplashActivity.this, MainActivity.class));
//            }
//
//        }, 5000);
//    }
//}
//

package cn.edu.bzu.ie.mysqldb;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

/**
 * 主界面业务逻辑代码
 */
public class SplashActivity extends AppCompatActivity implements View.OnClickListener {
    private Button btn_login,btn_add;     // 登录按钮

    private EditText et_uname, et_upass;  // 用户名、密码框

    private UserDao dao;   // 用户数据库操作类
    private Handler mainHandler ;     // 主线程


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initView();
    }

    private void initView(){

        et_uname = findViewById(R.id.et_uname);
        et_upass = findViewById(R.id.et_upass);

        btn_login = findViewById(R.id.btn_login);
        btn_add = findViewById(R.id.btn_add);

        dao = new UserDao();
        mainHandler = new Handler(getMainLooper());   // 获取主线程

        btn_login.setOnClickListener(this);
        btn_add.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btn_login:    // 登录按钮
                doLogin();
                break;
            case R.id.btn_add:
                // 代码桩，打开添加用户界面
                Intent intent = new Intent(this, UserAddActivity.class);
                startActivityForResult(intent, 1);
                break;
        }
    }


    // 执行登录操作
    private void doLogin(){
        final String uname = et_uname.getText().toString().trim(); //trim去掉字符串中的空格
        final String upass = et_upass.getText().toString().trim();

        if(TextUtils.isEmpty(uname)){
            CommonUtils.showShortMsg(this, "请输入用户名");
            et_uname.requestFocus();
        }else if(TextUtils.isEmpty(upass)){
            CommonUtils.showShortMsg(this, "请输入用户密码");
            et_upass.requestFocus();
        }else{
            new Thread(new Runnable() {
                @Override
                public void run() {
                    final Userinfo item = dao.getUserByUnameAndUpass(uname, upass);

                    mainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            if(item == null){
                                CommonUtils.showDlgMsg(SplashActivity.this, "用户名或密码错误");
                            }else{
                                //CommonUtils.showDlgMsg(MainActivity.this, "登录成功，进入用户管理");
                                CommonUtils.showLonMsg(SplashActivity.this, "欢迎进入Recur健身");
                                // 调用用户管理界面
                                Intent intent = new Intent(SplashActivity.this, FenLei.class);
                                startActivity(intent);
                            }
                        }
                    });
                }
            }).start();
        }
    }
}
