package cn.edu.bzu.ie.mysqldb;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class BmiCount extends AppCompatActivity {

    private Button b1,b2;
    private RadioButton man,woman;
    private EditText heightText,weightText;
    private TextView bmi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bmi);

        //以下为变量与控件的绑定
        b1 = (Button) findViewById(R.id.b1);
        heightText = (EditText) findViewById(R.id.H);
        weightText = (EditText) findViewById(R.id.W);
        b2 = (Button) findViewById(R.id.b2);
        man = findViewById(R.id.man);
        woman = findViewById(R.id.woman);
        bmi = findViewById(R.id.BMI);

        //button2的点击响应，作用为清空所有输入
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                heightText.setText("");
                weightText.setText("");
            }
        });
        //button2的点击事件响应，计算BMI的值，结果用Toast显示
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //得到身高体重
                String height = heightText.getText().toString();
                String weight = weightText.getText().toString();
                double result = 0, heightNum = 0, weightNum = 0;
                if(!height.isEmpty()&&!weight.isEmpty()) {
                    heightNum = Double.parseDouble(height);
                    weightNum = Double.parseDouble(weight);
                    result = weightNum / (heightNum*heightNum);
                    bmi.setText((Double.toString(result)));
                }
                if(man.isChecked()){//如果选择的是男性
                    if(result <= 19)
                    {
                        Toast.makeText(BmiCount.this,"体重偏低",Toast.LENGTH_SHORT).show();
                    }
                    else if(result <= 24 && result > 19)
                    {
                        Toast.makeText(BmiCount.this,"健康体重",Toast.LENGTH_SHORT).show();
                    }
                    else if(result <= 30 && result > 24)
                    {
                        Toast.makeText(BmiCount.this,"超重",Toast.LENGTH_SHORT).show();
                    }
                    else if(result < 39 && result > 30)
                    {
                        Toast.makeText(BmiCount.this,"严重超重",Toast.LENGTH_SHORT).show();
                    }
                    else {
                        Toast.makeText(BmiCount.this,"极度超重",Toast.LENGTH_SHORT).show();
                    }

                }else//选择的是女性
                {
                    if (result <= 18) {
                        Toast.makeText(BmiCount.this, "体重偏低", Toast.LENGTH_SHORT).show();
                    } else if (result <= 24 && result > 18) {
                        Toast.makeText(BmiCount.this, "健康体重", Toast.LENGTH_SHORT).show();
                    } else if (result <= 29 && result > 24) {
                        Toast.makeText(BmiCount.this, "超重", Toast.LENGTH_SHORT).show();
                    } else if (result < 38 && result > 29) {
                        Toast.makeText(BmiCount.this, "严重超重", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(BmiCount.this, "极度超重", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}

