package cn.edu.bzu.ie.mysqldb;

import android.view.View;

/**
 * 删除按钮的点击事件监听接口
 */
public interface OnDelBtnClickListener {
    void onDelBtnClick(View view, int position);   // 删除按钮的点击事件处理
}
