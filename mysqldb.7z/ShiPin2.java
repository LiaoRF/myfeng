package cn.edu.bzu.ie.mysqldb;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.MediaController;
import android.widget.VideoView;

import androidx.appcompat.app.AppCompatActivity;

public class ShiPin2 extends AppCompatActivity {
    private VideoView videoView;
    private Button btn_start,btn_end;
    private Button Button5;
    private MediaController mediaController;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.avtivity_shipin);
        Button5=findViewById(R.id.button5);
        initView();
        Button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //创建Intent 对象
                Intent intent=new Intent(ShiPin2.this,ShangPin.class);
                //启动Activity
                startActivity(intent);
            }
        });
    }

    private void initView() {
        videoView= (VideoView) findViewById(R.id.videoView);
        btn_start= (Button) findViewById(R.id.btn_start);
        btn_end= (Button) findViewById(R.id.btn_end);


        btn_start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                init();
            }
        });
        btn_end.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                videoView.stopPlayback();
            }
        });
    }

    private void init() {
        videoView = (VideoView) findViewById(R.id.videoView);
        mediaController = new MediaController(this);
        String uri = "android.resource://" + getPackageName() + "/" + R.raw.fubu;
        // String uri = "https://haokan.baidu.com/v?pd=wisenatural&vid=4099467760051976196";
        videoView.setVideoURI(Uri.parse(uri));
        videoView.setMediaController(mediaController);
        mediaController.setMediaPlayer(videoView);
        videoView.requestFocus();
        videoView.start();
    }


//    private void init() {
//        String url="http://ivi.bupt.edu.cn/hls/cctv6hd.m3u8";
//        VideoView videoView=findViewById(R.id.videoView);
//        videoView.setVideoPath(url);
//        videoView.requestFocus();
//        videoView.start();
//    }
}
