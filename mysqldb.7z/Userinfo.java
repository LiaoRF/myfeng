package cn.edu.bzu.ie.mysqldb;

import java.io.Serializable;

/**
 * 用户信息实体类
 */
public class Userinfo implements Serializable {
    private int id;    // 用户的id
    private String name;   // 用户名
    private String password;   // 用户密码
    private String createDt;   // 创建时间

    public Userinfo() {
    }

    public Userinfo(int id, String uname, String upass, String createDt) {
        this.id = id;
        this.name = uname;
        this.password = upass;
        this.createDt = createDt;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUname() {
        return name;
    }

    public void setUname(String uname) {
        this.name = uname;
    }

    public String getUpass() {
        return password;
    }

    public void setUpass(String upass) {
        this.password = upass;
    }

    public String getCreateDt() {
        return createDt;
    }

    public void setCreateDt(String createDt) {
        this.createDt = createDt;
    }
}
