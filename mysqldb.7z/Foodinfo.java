package cn.edu.bzu.ie.mysqldb;

import java.io.Serializable;

/**
 * 食物信息实体类
 */
public class Foodinfo implements Serializable {
    private int id;    // 食物的id
    private String foodname;   // 食物名字
    private String foodif;   // 食物信息
    private String createDt;   // 创建时间

    public Foodinfo() {
    }

    public Foodinfo(int id, String foodname, String foodif, String createDt) {
        this.id = id;
        this.foodname = foodname;
        this.foodif = foodif;
        this.createDt = createDt;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFoodname() {
        return foodname;
    }

    public void setFoodname(String foodname) {
        this.foodname = foodname;
    }

    public String getFoodif() {
        return foodif;
    }

    public void setFoodif(String foodif) {
        this.foodif = foodif;
    }

    public String getCreateDt() {
        return createDt;
    }

    public void setCreateDt(String createDt) {
        this.createDt = createDt;
    }
}
