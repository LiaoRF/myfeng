package cn.edu.bzu.ie.mysqldb;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

/**
 * 自定义用户数据适配器类
 */
public class LvTeacherinfoAdapter extends BaseAdapter {
    private Context context;    // 上下文信息
    private List<Teacherinfo> teacherinfoList;    // 用户信息数据集合

    public LvTeacherinfoAdapter() {
    }

    public LvTeacherinfoAdapter(Context context, List<Teacherinfo> teacherinfoList) {
        this.context = context;
        this.teacherinfoList = teacherinfoList;
        Log.i("数据适配器", "用户数量："+teacherinfoList.size());
    }

    public void setTeacherinfoList(List<Teacherinfo> teacherinfoList) {
        this.teacherinfoList = teacherinfoList;
    }

    @Override
    public int getCount() {
        return teacherinfoList.size();
    }

    @Override
    public Object getItem(int position) {
        return teacherinfoList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder = null;
        if(convertView==null){
            convertView = LayoutInflater.from(context).inflate(R.layout.teacher_list_item, null);
            viewHolder = new ViewHolder();

            viewHolder.tv_id = convertView.findViewById(R.id.tv_id);
            viewHolder.tv_teachername = convertView.findViewById(R.id.tv_teachername);
            viewHolder.tv_teacherpass = convertView.findViewById(R.id.tv_teacherpass);
            viewHolder.tv_createDt = convertView.findViewById(R.id.tv_createDt);

            convertView.setTag(viewHolder);
        }else{
            viewHolder = (ViewHolder) convertView.getTag();
        }

        // 这里进行数据填充
        Teacherinfo item = teacherinfoList.get(position);
        viewHolder.tv_id.setText(item.getId()+".");
        viewHolder.tv_teachername.setText(item.getTeachername());
        viewHolder.tv_teacherpass.setText(item.getTeacherpass());
        viewHolder.tv_createDt.setText(item.getCreateDt());



        return convertView;
    }

    // 自定义内部类
    private class ViewHolder{
        private TextView tv_id, tv_teachername, tv_teacherpass, tv_createDt;
        private ImageView btn_edit, btn_delete;
    }
}
