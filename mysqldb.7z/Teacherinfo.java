package cn.edu.bzu.ie.mysqldb;

import java.io.Serializable;

/**
 * 教练信息实体类
 */
public class Teacherinfo implements Serializable {
    private int id;    // 用户的id
    private String teachername;   // 用户名
    private String teacherpass;   // 用户密码
    private String createDt;   // 创建时间

    public Teacherinfo() {
    }

    public Teacherinfo(int id, String teachername, String teacherpass, String createDt) {
        this.id = id;
        this.teachername = teachername;
        this.teacherpass = teacherpass;
        this.createDt = createDt;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTeachername() {
        return teachername;
    }

    public void setTeachername(String teachername) {
        this.teachername = teachername;
    }

    public String getTeacherpass() {
        return teacherpass;
    }

    public void setTeacherpass(String teacherpass) {
        this.teacherpass = teacherpass;
    }

    public String getCreateDt() {
        return createDt;
    }

    public void setCreateDt(String createDt) {
        this.createDt = createDt;
    }
}
