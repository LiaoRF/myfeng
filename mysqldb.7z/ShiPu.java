package cn.edu.bzu.ie.mysqldb;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ShiPu extends AppCompatActivity {
    private TextView tv_main_title;//标题
    private TextView tv_back;
    private RelativeLayout rl_title_bar;
    private Button Button4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shipu);
        tv_back=findViewById(R.id.tv_back);

        tv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //创建Intent 对象
                Intent intent=new Intent(ShiPu.this,FenLei.class);
                //启动Activity
                startActivity(intent);
            }
        });

    }
}
